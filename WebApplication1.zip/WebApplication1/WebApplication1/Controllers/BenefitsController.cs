﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BenefitsController : ControllerBase
    {
        private readonly ILogger<BenefitsController> _logger;
        private readonly IUserService _userService;
        private readonly ICostService _costService;

        public BenefitsController(ILogger<BenefitsController> logger, IUserService benefitService, ICostService costService)
        {
            _logger = logger;
            this._userService = benefitService;
            this._costService = costService;
        }

        [HttpPost]
        [Route("dependents/{companyId:min(1)}")]
        public async Task<JsonResult> AddDependents(ulong companyId, AddDependentDto addDependentsDto)
        {
            //validation logic for dto
            
            await _userService.AddDependents(companyId, addDependentsDto.UserId, addDependentsDto.Dependents);
            return JsonResultWithStatusCode(200, await _userService.GetDependents(companyId, addDependentsDto.UserId));
        }

        [HttpGet]
        [Route("dependents/{companyId:min(1)}/{userId:min(1)}")]
        public async Task<JsonResult> GetDependents(ulong companyId, ulong userId)
        {
            return JsonResultWithStatusCode(200, await _userService.GetDependents(companyId, userId));
        }

        [HttpGet]
        [Route("previewcost/{companyId:min(1)}/{userId:min(1)}")]
        public async Task<JsonResult> PreviewCosts(ulong companyId, ulong userId)
        {
            return JsonResultWithStatusCode(200, await _costService.PreviewCosts(companyId, userId));
        }

        [HttpPost]
        [Route("payroll/{companyId:min(1)}/{userId:min(1)}")]
        public async Task<JsonResult> ApprovePayroll(ulong companyId, ulong userId, [FromBody]List<ulong> userIds)
        {
            //check if the user has privilege to perform this operation
            if(HasAdminPrivilege(companyId, userId))
            {
                await _costService.ApproveCost(companyId, userIds);
                return JsonResultWithStatusCode(200, "Payroll approved!");
            }

            return JsonResultWithStatusCode(400, "Not an admin!");
        }

        private bool HasAdminPrivilege(ulong companyId, ulong userId)
        {
            return true;
        }

        private JsonResult JsonResultWithStatusCode(int code, object value)
        {
            JsonResult result = new JsonResult(value);
            result.StatusCode = (int)code;
            return result;
        }

    }
}
