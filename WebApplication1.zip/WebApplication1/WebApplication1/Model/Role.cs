﻿using System.Collections.Generic;

namespace WebApplication1.Model
{
    public class Role
    {
        public List<Privilege> Privileges { get; set; }

        public RoleType RoleType { get; set; }

        public ulong Id { get; set; }
    }
}
