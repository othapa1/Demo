﻿namespace WebApplication1.Model
{
    public enum RoleType
    {
        General,
        Admin,
        Other
    }
}
