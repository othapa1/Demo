﻿using System;

namespace WebApplication1.Model
{
    public class PayCheck
    {
        public ulong Id { get; set; }

        public ulong UserId { get; set; }

        public DateTime Date { get; set; }

        public double TotalPay { get; set; }

        public double Deduction { get; set; }
    }
}
