﻿using System.Collections.Generic;
using WebApplication1.Model;

namespace WebApplication1.Controllers
{
    public class AddDependentDto
    {
        public ulong CompanyId { get; set; }

        public ulong UserId { get; set; }

        public List<Dependent> Dependents = new List<Dependent>();
    }
}