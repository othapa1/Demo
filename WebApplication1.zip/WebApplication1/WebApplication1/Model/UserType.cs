﻿namespace WebApplication1.Model
{
    public enum UserType
    {
        Employee,
        Dependent
    }
}
