﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Model
{
    public class CostPreviewDto
    {
        public ulong UserId { get; internal set; }
        public double Salary { get; internal set; }
        public int DependentCount { get; internal set; }
        public int Deduction { get; internal set; }
        public double NetPay { get; internal set; }
    }
}
