﻿using System.Collections.Generic;

namespace WebApplication1.Model
{
    public class Privilege
    {
        public ulong Id { get; set; }

        public string Detail { get; set; }

        public List<string> Endpoints { get; set; }
    }
}
