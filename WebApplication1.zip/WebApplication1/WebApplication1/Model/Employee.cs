﻿using System.Collections.Generic;

namespace WebApplication1.Model
{
    public class Employee : User
    {
        public List<Role> Roles { get; set; }

        public double Salary { get; set; }

        public List<Dependent> Dependents { get; set; }
    }
}
