﻿namespace WebApplication1.Model
{
    public class Dependent : User
    {
        public ulong PrimaryId { get; set; }
    }
}
