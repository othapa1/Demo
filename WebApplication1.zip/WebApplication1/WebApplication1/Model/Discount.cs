﻿namespace WebApplication1.Model
{
    public class Discount
    {
        public ulong Id { get; set; }

        public string Detail { get; set; }

        public double Percentage { get; set; }
    }
}
