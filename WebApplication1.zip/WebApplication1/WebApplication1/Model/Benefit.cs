﻿namespace WebApplication1.Model
{
    public class Benefit
    {
        public ulong Id { get; set; }

        public double Cost { get; set; }

        public string Details { get; set; }

        public UserType UserType { get; set; }
    }
}
