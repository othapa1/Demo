﻿using System.Collections.Generic;

namespace WebApplication1.Model
{
    public class Company
    {
        public ulong Id { get; set; }
        public List<User> Users { get; set; }
    }
}
