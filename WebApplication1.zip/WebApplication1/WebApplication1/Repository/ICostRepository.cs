﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    public interface ICostRepository
    {
        Task<int> GetEmployeeBenefitCost();
        Task<int> GetDependentBenefitCost();
        Task ApproveCost(ulong companyId, List<ulong> userIds);
    }
}