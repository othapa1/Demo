﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Repository
{
    public class UserRepository : IUserRepository
    {
        //cached data to simulate cache layer
        private readonly Dictionary<ulong, List<Privilege>> RolePrivilegeDict = new Dictionary<ulong, List<Privilege>>();
        private readonly Dictionary<ulong, List<User>> UserDict = new Dictionary<ulong, List<User>>();

        public UserRepository()
        {
            //initialize the test data 
            InitializeTestData();
        }

        public Task<Employee> GetEmployee(ulong companyId, ulong userId)
        {
            if(UserDict.ContainsKey(companyId))
            {
                Employee employee = (Employee)UserDict[companyId].FirstOrDefault(u => u.Id == userId);
                return Task.FromResult(employee);
            }
            return Task.FromResult((Employee)null);
        }

        public Task<List<Dependent>> GetDependents(ulong companyId, ulong userId)
        {
            if (UserDict.ContainsKey(companyId))
            {
                Employee employee = (Employee)UserDict[companyId].FirstOrDefault(u => u.Id == userId);
                return Task.FromResult(employee.Dependents);
            }
            return Task.FromResult((List<Dependent>)null);
        }

        public Task AddDependents(ulong companyId, ulong userId, List<Dependent> dependents)
        {
            if (UserDict.ContainsKey(companyId))
            {
                Employee employee = (Employee)UserDict[companyId].FirstOrDefault(u => u.Id == userId);
                if(employee != null)
                {
                    employee.Dependents.AddRange(dependents);
                }
            }
            return Task.CompletedTask;
        }

        private void InitializeTestData()
        {
            var adminPrivileges = new List<Privilege>
            {
                new Privilege{ Id = 1, Detail="Approve Payroll", Endpoints = new List<string>{ "/approve_payroll"} }
            };

            var generalRole = new Role { Id = 1, RoleType = RoleType.General, Privileges = new List<Privilege>() };
            var adminRole = new Role { Id = 2, RoleType = RoleType.Admin, Privileges = adminPrivileges };

            RolePrivilegeDict.Add(generalRole.Id, generalRole.Privileges);
            RolePrivilegeDict.Add(adminRole.Id, adminRole.Privileges);

            var users = new List<User>()
            {
                new Employee
                {
                    Id = 101,
                    FirstName = "Sam",
                    LastName = "Smith",
                    Email="test1@company1.com",
                    Salary = 2000,
                    Roles= new List<Role>{ adminRole},
                    Dependents = new List<Dependent>
                    {
                        new Dependent
                        {
                            Id = 201,
                            FirstName = "Sam",
                            LastName = "Smith",
                            PrimaryId = 101
                        },
                        new Dependent
                        {
                            Id = 202,
                            FirstName = "John",
                            LastName = "Doe",
                            PrimaryId = 101
                        }
                    }
                },
                new Employee
                {
                    Id = 102,
                    FirstName = "Test",
                    LastName = "Doe",
                    Email="test2@company1.com",
                    Salary = 2000,
                    Roles= new List<Role>{ generalRole},
                    Dependents = new List<Dependent>
                    {
                        new Dependent
                        {
                            Id = 203,
                            FirstName = "Sam",
                            LastName = "Smith",
                            PrimaryId = 102
                        },
                        new Dependent
                        {
                            Id = 204,
                            FirstName = "John",
                            LastName = "Doe",
                            PrimaryId = 102
                        }
                    }}
                ,
                new Employee
                {
                    Id = 103,
                    FirstName = "Test",
                    LastName = "Doe",
                    Email="test2@company1.com",
                    Salary = 2000,
                    Roles= new List<Role>{ generalRole},
                    Dependents = new List<Dependent>()
                }
            };

            var testCompany = new Company
            {
                Id = 1001,
                Users = users
            };

            UserDict.Add(testCompany.Id, testCompany.Users);
        }
    }
}
