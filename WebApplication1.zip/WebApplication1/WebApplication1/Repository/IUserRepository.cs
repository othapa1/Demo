﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Repository
{
    public interface IUserRepository
    {
        Task<Employee> GetEmployee(ulong companyId, ulong userId);

        Task AddDependents(ulong companyId, ulong userId, List<Dependent> dependents);

        Task<List<Dependent>> GetDependents(ulong companyId, ulong userId);
    }
}