﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication1.Controllers;

namespace WebApplication1.Repository
{
    public class CostRepository : ICostRepository
    {
        public Task ApproveCost(ulong companyId, List<ulong> userIds)
        {
            //set it in db.
            return Task.CompletedTask;
        }

        public Task<int> GetDependentBenefitCost()
        {
            //should ideally get it from db
            return Task.FromResult((int)500);
        }

        public Task<int> GetEmployeeBenefitCost()
        {
            //should ideally get it from db
            return Task.FromResult((int)1000);
        }
    }
}
