﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication1.Model;

namespace WebApplication1.Controllers
{
    public interface IUserService
    {
        Task AddDependents(ulong companyId, ulong userId, List<Dependent> dependents);
        Task<List<Dependent>> GetDependents(ulong companyId, ulong userId);
    }
}