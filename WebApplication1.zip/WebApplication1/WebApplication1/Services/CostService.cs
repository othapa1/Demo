﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication1.Model;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{
    public class CostService : ICostService
    {
        private readonly IUserRepository _userRepo;

        private readonly ICostRepository _costRepo;

        public CostService(IUserRepository testRepo, ICostRepository costRepo)
        {
            _userRepo = testRepo;
            _costRepo = costRepo;
        }

        public async Task<CostPreviewDto> PreviewCosts(ulong companyId, ulong userId)
        {
            var user = await _userRepo.GetEmployee(companyId, userId);

            var totalDependents = user.Dependents.Count;
            var benefitDeduction = totalDependents * await _costRepo.GetDependentBenefitCost() + await _costRepo.GetEmployeeBenefitCost();

            //need somesort of business logic to handle when total deductible tends to be greater than salary

            return new CostPreviewDto()
            {
                UserId = user.Id,
                Salary = user.Salary,
                DependentCount = totalDependents,
                Deduction = benefitDeduction,
                NetPay = user.Salary - benefitDeduction
            };
        }

        public async Task ApproveCost(ulong companyId, List<ulong> userIds)
        {
            await _costRepo.ApproveCost(companyId, userIds);
        }
    }
}
