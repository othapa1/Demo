﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Model;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepo;

        public UserService(IUserRepository testRepo)
        {
            _userRepo = testRepo;
        }

        public async Task AddDependents(ulong companyId, ulong userId, List<Dependent> dependents)
        {
            await _userRepo.AddDependents(companyId, userId, dependents);
        }

        public async Task<List<Dependent>> GetDependents(ulong companyId, ulong userId)
        {
           return await _userRepo.GetDependents(companyId, userId);
        }
    }
}
